# == Schema Information
#
# Table name: books
#
#  id         :integer          not null, primary key
#  name       :string           not null
#  wizard_id  :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Book < ApplicationRecord
  validates :name,  presence: true

  belongs_to :author,
  foreign_key: 'wizard_id',
  primary_key: 'id',
  class_name: 'Wizard'

  has_many :spells,
  foreign_key: 'book_id',
  primary_key: 'id',
  class_name: 'Spell'
end
