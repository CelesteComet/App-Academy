# == Schema Information
#
# Table name: wands
#
#  id         :integer          not null, primary key
#  name       :string           not null
#  wizard_id  :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Wand < ApplicationRecord
  validates :name, presence: true
  
  belongs_to :wizard,
  foreign_key: 'wizard_id',
  primary_key: 'id',
  class_name: 'Wizard'
end
