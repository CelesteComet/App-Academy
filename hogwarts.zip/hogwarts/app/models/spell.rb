# == Schema Information
#
# Table name: spells
#
#  id         :integer          not null, primary key
#  name       :string           not null
#  book_id    :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Spell < ApplicationRecord
  validates :name, presence: true

  belongs_to :book,
  foreign_key: 'book_id',
  primary_key: 'id',
  class_name: 'Book'
end
