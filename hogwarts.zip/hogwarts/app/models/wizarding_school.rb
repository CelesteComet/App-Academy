# == Schema Information
#
# Table name: wizarding_schools
#
#  id         :integer          not null, primary key
#  name       :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class WizardingSchool < ApplicationRecord
  validates :name, presence: true

  has_many :houses,
  foreign_key: 'wizarding_school_id',
  primary_key: 'id',
  class_name: 'House'

  has_many :klasses,
  foreign_key: 'wizarding_school_id',
  primary_key: 'id',
  class_name: 'Klass'

end
