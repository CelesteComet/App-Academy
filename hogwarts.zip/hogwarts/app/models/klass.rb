# == Schema Information
#
# Table name: klasses
#
#  id                  :integer          not null, primary key
#  name                :string           not null
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#  wizarding_school_id :integer          not null
#

class Klass < ApplicationRecord
  validates :name, presence: true

  has_many :memberships,
  foreign_key: 'class_id',
  primary_key: 'id',
  class_name: 'KlassMembership'

  belongs_to :wizarding_school,
  foreign_key: 'wizarding_school_id',
  primary_key: 'id',
  class_name: 'WizardingSchool'

  has_many :students,
  through: 'memberships',
  source: 'wizard'
end
