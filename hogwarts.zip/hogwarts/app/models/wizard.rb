# == Schema Information
#
# Table name: wizards
#
#  id         :integer          not null, primary key
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  name       :string           not null
#

class Wizard < ApplicationRecord

  has_many :authored_books,
  foreign_key: 'wizard_id',
  primary_key: 'id',
  class_name: 'Book'

  has_one :house_membership,
  foreign_key: 'wizard_id',
  primary_key: 'id',
  class_name: 'HouseMembership'

  has_one :house,
  through: 'house_membership',
  source: 'house'

  has_many :wands,
  foreign_key: 'wizard_id',
  primary_key: 'id',
  class_name: 'Wand'

  
end
