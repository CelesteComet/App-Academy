# == Schema Information
#
# Table name: houses
#
#  id                  :integer          not null, primary key
#  name                :string           not null
#  wizarding_school_id :integer          not null
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#

class House < ApplicationRecord
  validates :name, presence: true
  validates :wizarding_school_id, presence: true

  belongs_to :wizarding_school,
  foreign_key: 'wizarding_school_id',
  primary_key: 'id',
  class_name: 'WizardingSchool'

  has_many :house_memberships,
  foreign_key: 'house_id',
  primary_key: 'id',
  class_name: 'HouseMembership'

  has_many :wizards,
  through: 'house_memberships',
  source: 'wizard'

end
