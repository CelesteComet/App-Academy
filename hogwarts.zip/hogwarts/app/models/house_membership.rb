# == Schema Information
#
# Table name: house_memberships
#
#  id         :integer          not null, primary key
#  wizard_id  :integer          not null
#  house_id   :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class HouseMembership < ApplicationRecord

  belongs_to :wizard,
  foreign_key: 'wizard_id',
  primary_key: 'id',
  class_name: 'Wizard'

  belongs_to :house,
  foreign_key: 'house_id',
  primary_key: 'id',
  class_name: 'House'

  has_many :wizards,
  foreign_key: 'house_membership_id',
  primary_key: 'id',
  class_name: 'Wizard'

end
