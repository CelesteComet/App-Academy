# == Schema Information
#
# Table name: klass_memberships
#
#  id         :integer          not null, primary key
#  wizard_id  :integer          not null
#  class_id   :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class KlassMembership < ApplicationRecord
  belongs_to :wizard,
  foreign_key: 'wizard_id',
  primary_key: 'id',
  class_name: 'Wizard'

  belongs_to :klass, 
  foreign_key: 'class_id',
  primary_key: 'id',
  class_name: 'Klass'
end
