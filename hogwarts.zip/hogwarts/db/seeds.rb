# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


hogwarts = WizardingSchool.create({ name: "Hogwarts" })

gryffindor = House.create!({ name: 'Gryffindor', wizarding_school_id: 1 })
hufflepuff = House.create!({ name: 'Hufflepuff', wizarding_school_id: 1 })
ravenclaw = House.create!({ name: 'Ravenclaw', wizarding_school_id: 1 })
slytherin = House.create!({ name: 'Slytherin', wizarding_school_id: 1 })

harry_potter = Wizard.create({ 
  name: "Harry Potter"
})

emma_watson = Wizard.create({
  name: "Emma Watson"
})

random_wand = Wand.create({
  name: "Random Wand",
  wizard_id: 1
})

another_rando = Wand.create({
  name: "Another Rando Wand",
  wizard_id: 2
})

the_essence_of_nerd = Book.create({
  name: "The Essense of Nerd",
  wizard_id: 1
})

the_essence_of_hair = Book.create({
  name: "The Essense of Hair",
  wizard_id: 2
})

Spell.create({ name: "wingardium leviosa", book_id: 1})
Spell.create({ name: "wingardium killosnapesa", book_id: 1})
Spell.create({ name: "wingardium harriosa", book_id: 2})

HouseMembership.create({
  wizard_id: 1,
  house_id: 1
})

HouseMembership.create({
  wizard_id: 2,
  house_id: 2 
})

Klass.create({ 
  name: "Ruby 101",
  wizarding_school_id: 1
})

KlassMembership.create({
  wizard_id: 1,
  class_id: 1
})









