class RemoveColumnIdsFromWizards < ActiveRecord::Migration[5.1]
  def change
    remove_column :wizards, :wizarding_school_id
    remove_column :wizards, :class_membership_id
    remove_column :wizards, :house_membership_id
  end
end
