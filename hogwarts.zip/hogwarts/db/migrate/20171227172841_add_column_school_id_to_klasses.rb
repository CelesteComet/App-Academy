class AddColumnSchoolIdToKlasses < ActiveRecord::Migration[5.1]
  def change
    add_column :klasses, :wizarding_school_id, :integer, null: false
  end
end
