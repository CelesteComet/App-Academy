class AddColumnWizardsName < ActiveRecord::Migration[5.1]
  def change
    add_column :wizards, :name, :string, null: false
  end
end
