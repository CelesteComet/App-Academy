class RemoveIndexOnManyThings < ActiveRecord::Migration[5.1]
  def change
    remove_index :books, :wizard_id
    add_index :books, :wizard_id

    remove_index :spells, :book_id
    add_index :spells, :book_id

    remove_index :klass_memberships, :class_id
    add_index :klass_memberships, :class_id
    remove_index :klass_memberships, :wizard_id
    add_index :klass_memberships, :wizard_id

  end
end
