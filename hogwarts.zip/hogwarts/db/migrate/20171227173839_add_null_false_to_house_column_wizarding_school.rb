class AddNullFalseToHouseColumnWizardingSchool < ActiveRecord::Migration[5.1]
  def change
    remove_column :houses, :wizarding_school_id
    add_column :houses, :wizarding_school_id, :integer, null: false
  end
end
