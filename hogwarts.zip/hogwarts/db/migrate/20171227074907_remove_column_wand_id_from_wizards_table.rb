class RemoveColumnWandIdFromWizardsTable < ActiveRecord::Migration[5.1]
  def change
    remove_column :wizards, :wand_id
  end
end
