class CreateHouseMemberships < ActiveRecord::Migration[5.1]
  def change
    create_table :house_memberships do |t|
      t.integer :wizard_id, null: false
      t.integer :house_id, null: false

      t.timestamps
    end
    add_index :house_memberships, :wizard_id
    add_index :house_memberships, :house_id
  end
end
