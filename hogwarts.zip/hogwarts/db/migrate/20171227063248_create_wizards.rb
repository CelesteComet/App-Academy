class CreateWizards < ActiveRecord::Migration[5.1]
  def change
    create_table :wizards do |t|
      t.string :name, null: false
      t.integer :wand_id
      t.integer :wizarding_school_id
      t.integer :house_membership_id
      t.string :class_membership_id

      t.timestamps
    end
    add_index :wizards, :wand_id, unique: true
    add_index :wizards, :wizarding_school_id, unique: true
    add_index :wizards, :house_membership_id, unique: true
    add_index :wizards, :class_membership_id, unique: true
  end
end
