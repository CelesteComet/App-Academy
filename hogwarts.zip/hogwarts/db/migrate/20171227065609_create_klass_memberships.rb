class CreateKlassMemberships < ActiveRecord::Migration[5.1]
  def change
    create_table :klass_memberships do |t|
      t.integer :wizard_id, null: false
      t.integer :class_id, null: false

      t.timestamps
    end
    add_index :klass_memberships, :wizard_id, unique: true
    add_index :klass_memberships, :class_id, unique: true
  end
end
