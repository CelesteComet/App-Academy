class CreateBooks < ActiveRecord::Migration[5.1]
  def change
    create_table :books do |t|
      t.string :name, null: false
      t.integer :wizard_id

      t.timestamps
    end
    add_index :books, :wizard_id, unique: true
  end
end
