class RemoveColumnNameFromWizards < ActiveRecord::Migration[5.1]
  def change
    remove_column :wizards, :name
  end
end
