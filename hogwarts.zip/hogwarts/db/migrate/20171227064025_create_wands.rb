class CreateWands < ActiveRecord::Migration[5.1]
  def change
    create_table :wands do |t|
      t.string :name, null: false
      t.integer :wizard_id

      t.timestamps
    end
    add_index :wands, :wizard_id, unique: true
  end
end
