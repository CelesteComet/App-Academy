class CreateSpells < ActiveRecord::Migration[5.1]
  def change
    create_table :spells do |t|
      t.string :name, null: false
      t.integer :book_id

      t.timestamps
    end
    add_index :spells, :book_id, unique: true
  end
end
