# == Schema Information
#
# Table name: house_memberships
#
#  id         :integer          not null, primary key
#  wizard_id  :integer          not null
#  house_id   :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

require 'test_helper'

class HouseMembershipTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
