# == Schema Information
#
# Table name: spells
#
#  id         :integer          not null, primary key
#  name       :string           not null
#  book_id    :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

require 'test_helper'

class SpellTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
