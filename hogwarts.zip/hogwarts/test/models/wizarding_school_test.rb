# == Schema Information
#
# Table name: wizarding_schools
#
#  id         :integer          not null, primary key
#  name       :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

require 'test_helper'

class WizardingSchoolTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
